import Link from "next/link";
import { requireRole } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

export default async function LandlordOverviewPage() {
  const profile = await requireRole("LANDLORD", "ADMIN");

  const properties = await prisma.property.findMany({
    where: profile.role === "ADMIN" ? {} : { landlordId: profile.id },
    include: {
      units: {
        include: {
          tenancies: { where: { status: "ACTIVE" }, include: { tenant: true } },
          maintenanceReqs: { where: { status: { not: "RESOLVED" } } },
        },
      },
    },
    orderBy: { createdAt: "desc" },
  });

  return (
    <div>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
        <h1>Your properties</h1>
        <Link className="btn" href="/dashboard/landlord/properties/new">+ Add property</Link>
      </div>

      {properties.length === 0 && (
        <p className="muted">No properties yet. Add your first one to get started.</p>
      )}

      {properties.map((property) => (
        <div className="card" key={property.id}>
          <div style={{ display: "flex", justifyContent: "space-between" }}>
            <div>
              <strong>{property.addressLine}</strong>
              <p className="muted">{property.suburb}, {property.town}</p>
            </div>
            <Link className="btn secondary" href={`/dashboard/landlord/properties/${property.id}`}>
              Manage
            </Link>
          </div>
          <table style={{ marginTop: 10 }}>
            <thead>
              <tr><th>Unit</th><th>Rent</th><th>Tenant</th><th>Open tickets</th></tr>
            </thead>
            <tbody>
              {property.units.map((unit) => (
                <tr key={unit.id}>
                  <td>{unit.unitLabel}</td>
                  <td>N${unit.rentAmount.toLocaleString()}</td>
                  <td>{unit.tenancies[0]?.tenant.fullName ?? <span className="muted">Vacant</span>}</td>
                  <td>{unit.maintenanceReqs.length}</td>
                </tr>
              ))}
              {property.units.length === 0 && (
                <tr><td colSpan={4} className="muted">No units added yet.</td></tr>
              )}
            </tbody>
          </table>
        </div>
      ))}
    </div>
  );
}
