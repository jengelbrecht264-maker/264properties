import Link from "next/link";
import { requireRole } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

export default async function TenantOverviewPage() {
  const profile = await requireRole("TENANT");

  const tenancies = await prisma.tenancy.findMany({
    where: { tenantId: profile.id },
    include: { unit: { include: { property: true } }, lease: true },
    orderBy: { createdAt: "desc" },
  });

  const notifications = await prisma.notification.findMany({
    where: { userId: profile.id, readAt: null },
    orderBy: { createdAt: "desc" },
    take: 10,
  });

  return (
    <div>
      <h1>Your tenancies</h1>

      {notifications.length > 0 && (
        <div className="flag">
          {notifications.length} unread notification{notifications.length === 1 ? "" : "s"}
        </div>
      )}

      {tenancies.length === 0 && <p className="muted">No tenancies on file yet.</p>}

      {tenancies.map((t) => (
        <div className="card" key={t.id}>
          <strong>{t.unit.property.addressLine}</strong> ({t.unit.unitLabel})
          <p className="muted">
            Rent: N${t.rentAmount.toLocaleString()}/month — Lease ends {t.endDate.toLocaleDateString()}
          </p>
          <div style={{ display: "flex", gap: 8 }}>
            <Link className="btn secondary" href={`/dashboard/landlord/leases/${t.id}`}>
              {t.lease ? "View lease" : "No lease yet"}
            </Link>
            <Link className="btn secondary" href={`/dashboard/messages/${t.id}`}>
              Message landlord
            </Link>
          </div>
        </div>
      ))}
    </div>
  );
}
